# Contributing to TapBridge

Thanks for helping improve TapBridge.

## Before opening an issue
- Check existing issues for duplicates.
- Include device model, Android version, and clear reproduction steps.
- Do not attach personal data, credentials, or unrelated app data.

## Pull requests
- Keep changes focused and explain the user-visible impact.
- Preserve the minimum supported Android version unless a change is discussed first.
- Run `gradle :app:assembleDebug` before submitting when possible.
- Describe device testing separately from build success. A successful CI build does not prove compatibility with every device or game.

## Scope and safety
TapBridge is intended for accessibility and ordinary input remapping. Contributions must not add anti-cheat bypasses, stealth behavior, credential collection, or mechanisms to evade app protections.

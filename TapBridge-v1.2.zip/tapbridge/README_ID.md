# TapBridge: Panduan (Bahasa Indonesia)

TapBridge mengubah tombol keyboard/gamepad menjadi sentuhan layar. Game **tidak perlu mendukung gamepad**: game hanya "merasa" layarnya disentuh.

## Install
1. Unduh `TapBridge-debug.apk` dari tab **Releases** (atau Artifacts di Actions), lalu install. Izinkan "Install dari sumber tidak dikenal".

## Langkah 1 — Beri izin
- Ketuk **Aktifkan Accessibility**, pilih TapBridge, nyalakan.
- Android 13+: jika tombolnya abu-abu, ketuk **Buka info aplikasi**, tekan menu ⋮ di pojok kanan atas, pilih **Izinkan setelan terbatas**, lalu ulangi.
- Ketuk **Izinkan tampil di atas aplikasi**.
- Kotak hijau ✓ = izin sudah beres.

## Langkah 2 — Pilih tombol
- Gerak karakter: ketuk **Keyboard WASD** atau **D-pad / Panah**.
- Tombol aksi (serang, lompat): ketuk **+ Tambah tombol**, lalu tekan tombolnya.
- **Tes tombol**: tekan tombol apa saja di layar ini. Jika muncul "✓ Terbaca", berarti HP menerima tombol itu.
- Ketuk kotak mode di tiap baris untuk mengganti: **Ketuk** (1x), **Tahan**, **Ketuk Cepat**, **Gerak**.

## Langkah 3 — Atur posisi lalu main
1. Ketuk **▶ Tampilkan tombol TB**.
2. Buka game (orientasi layar yang akan dipakai main).
3. Tekan **lama** tombol bulat **TB**. Geser lingkaran biru ke tombol yang sama di game. Lingkaran **JOY** diletakkan di pusat joystick game. Tekan **SELESAI**.
4. Main. **TB hijau = ON**, abu-abu = OFF (ketuk TB untuk mengganti).

## Jika tidak berfungsi
- Pastikan TB menunjukkan ON dan posisi diatur di orientasi yang sama dengan saat main.
- Joystick game sebaiknya tipe *floating* (muncul di mana pun disentuh) atau letakkan JOY tepat di pusatnya. Ubah ukuran di **Pengaturan lanjutan**.
- Gunakan **Tes tombol** untuk memastikan tombolmu terbaca.

## Batasan
- Stik analog gamepad belum bisa dipetakan (Android tidak mengirimkannya sebagai tombol). D-pad dan tombol bisa. Untuk gerak pakai D-pad atau keyboard WASD.
- Menyentuh layar dengan jari dapat memutus sentuhan dari TapBridge.
- Beberapa game menolak input sintetis. Tidak ada bypass anti-cheat; pakai hanya jika diizinkan game.

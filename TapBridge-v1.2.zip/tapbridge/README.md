# TapBridge

**Android keyboard/gamepad-to-touch mapper**

TapBridge memetakan tombol keyboard atau gamepad fisik ke sentuhan layar memakai Android Accessibility Service. Tanpa root, tanpa internet.

> Status: v1.2.0. Kode belum diuji di perangkat fisik oleh pembuatnya; uji dulu di game yang kamu pakai.

## Fitur

- **Tap**: satu sentuhan singkat saat tombol ditekan.
- **Tahan**: sentuhan tertahan selama tombol ditekan (mis. tombol tembak/lari).
- **Rapid**: tap berulang selama tombol ditahan.
- **Joystick virtual**: tombol WASD / D-pad menggerakkan satu sentuhan tertahan dari pusat joystick (8 arah). Posisi dan radius bisa diatur.
- **Multi-touch simultan**: beberapa tombol dapat aktif bersamaan (joystick + tombol serang).
- Preset satu-ketuk untuk WASD dan D-pad/panah.
- GUI tiga langkah (izin, pilih tombol, atur posisi) dengan Tes tombol bawaan.
- Tidak butuh dukungan gamepad dari game: tombol diubah jadi sentuhan layar.
- Tombol mengambang TB: sekali tekan on/off, tekan lama untuk edit posisi.
- Mapping disimpan lokal di perangkat.

## Batasan Android

- Hanya tombol yang dikirim Android sebagai `KeyEvent`. Analog stick dan trigger analog fisik belum didukung.
- `dispatchGesture()` dapat dibatalkan jika jari menyentuh layar saat sentuhan sintetis berjalan.
- Atur posisi di orientasi yang sama dengan saat bermain.
- Beberapa game menolak input sintetis atau membatasi overlay. TapBridge tidak mencoba melewati anti-cheat. Pakai hanya jika diizinkan oleh game terkait.

## Build

Butuh JDK 17, Gradle 8.7, Android SDK 35.

```bash
gradle :app:assembleDebug
```

APK: `app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions dan download APK

- Setiap push ke `main` membangun APK; unduh dari **Actions > run terbaru > Artifacts** (disimpan 14 hari).
- Untuk link download permanen, buat tag versi, mis. `v1.2.0`. Workflow akan membuat **Release** berisi `TapBridge-debug.apk` di tab **Releases**.

Ini APK debug, bukan build rilis Play Store.

## Instalasi di Android 13+

Karena APK di-install dari luar Play Store, opsi Accessibility bisa abu-abu. Buka **Info Aplikasi TapBridge > menu ⋮ > Izinkan setelan terbatas**, lalu aktifkan lagi di Pengaturan > Aksesibilitas.

Panduan lengkap: [README_ID.md](README_ID.md).

# No custom ProGuard rules are required for this v1 project.

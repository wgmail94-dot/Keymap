package com.tapbridge.mapper

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

class MapperAccessibilityService : AccessibilityService() {
    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private var editorView: FrameLayout? = null
    private var markerView: FrameLayout? = null
    private var bubbleView: TextView? = null

    private var receiverRegistered = false

    private val engine: TouchEngine by lazy {
        TouchEngine(
            this@MapperAccessibilityService,
            mainHandler,
            { screenSize() },
            { MappingStore.joystick(this@MapperAccessibilityService) }
        )
    }

    private val serviceReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                ACTION_SHOW_EDITOR -> showEditor()
                ACTION_STOP_OVERLAY -> stopOverlay()
                ACTION_REFRESH_OVERLAY -> {
                    if (editorView == null && bubbleView != null) showRuntimeOverlay()
                }
                ACTION_START_OVERLAY -> {
                    if (SettingsCompat.canDrawOverlays(this@MapperAccessibilityService)) showRuntimeOverlay()
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        try {
            serviceInfo = serviceInfo.apply {
                flags = flags or android.accessibilityservice.AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            }
        } catch (_: Exception) {
            // The XML service metadata also requests key filtering.
        }
        registerActionReceiver()
        if (MappingStore.isEnabled(this)) {
            mainHandler.postDelayed({
                if (MappingStore.isEnabled(this)) showRuntimeOverlay()
            }, 300L)
        }
        sendStateChanged()
    }

    private fun registerActionReceiver() {
        if (receiverRegistered) return
        val filter = IntentFilter().apply {
            addAction(ACTION_SHOW_EDITOR)
            addAction(ACTION_STOP_OVERLAY)
            addAction(ACTION_REFRESH_OVERLAY)
            addAction(ACTION_START_OVERLAY)
        }
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(serviceReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("DEPRECATION")
            registerReceiver(serviceReceiver, filter)
        }
        receiverRegistered = true
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Rotasi layar mengubah ukuran layar: bangun ulang penanda agar posisinya tetap tepat.
        if (bubbleView != null && editorView == null) {
            mainHandler.postDelayed({
                if (bubbleView != null && editorView == null) showRuntimeOverlay()
            }, 250L)
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode

        // Selalu lepaskan sentuhan saat tombol dilepas, meskipun mapping baru dimatikan.
        if (event.action == KeyEvent.ACTION_UP) engine.keyUp(keyCode)

        if (MappingStore.isCapturing(this)) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 &&
                !ButtonMapping.isReservedKey(keyCode)
            ) {
                MappingStore.setCapturing(this, false)
                sendBroadcast(
                    Intent(ACTION_KEY_CAPTURED)
                        .setPackage(packageName)
                        .putExtra(EXTRA_KEY_CODE, keyCode)
                )
                return true
            }
            return false
        }

        if (!MappingStore.isEnabled(this)) return false
        val mapping = MappingStore.find(this, keyCode) ?: return false

        when (event.action) {
            KeyEvent.ACTION_DOWN -> {
                if (event.repeatCount == 0) {
                    val direction = ButtonMapping.directionOf(mapping.mode)
                    when {
                        direction >= 0 -> engine.directionDown(keyCode, direction)
                        mapping.mode == ButtonMapping.MODE_HOLD -> engine.holdDown(keyCode, mapping.x, mapping.y)
                        mapping.mode == ButtonMapping.MODE_RAPID -> engine.rapidStart(keyCode, mapping.x, mapping.y)
                        else -> engine.tap(mapping.x, mapping.y)
                    }
                }
                return true
            }
            KeyEvent.ACTION_UP -> return true
        }
        return false
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {
        // This mapper does not inspect app window contents.
    }

    override fun onInterrupt() {
        engine.releaseAll()
    }

    private fun showEditor() {
        if (!SettingsCompat.canDrawOverlays(this)) {
            Toast.makeText(this, "Izin overlay belum diberikan.", Toast.LENGTH_SHORT).show()
            return
        }
        MappingStore.setEnabled(this, false)
        engine.releaseAll()
        removeView(editorView)
        removeView(markerView)
        removeView(bubbleView)
        editorView = null
        markerView = null
        bubbleView = null

        val screen = screenSize()
        val root = FrameLayout(this).apply {
            setBackgroundColor(0x5C0B1220)
            isClickable = true
        }

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(8), dp(12), dp(8))
            background = rounded(Color.rgb(15, 23, 42), 0)
        }
        val instruction = TextView(this).apply {
            text = "Geser lingkaran ke tombol di game, lalu tekan SELESAI"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        toolbar.addView(instruction, LinearLayout.LayoutParams(0, dp(48), 1f))
        toolbar.addView(toolbarButton("BATAL") {
            removeView(editorView)
            editorView = null
            showRuntimeOverlay()
        })
        toolbar.addView(
            toolbarButton("SELESAI") {
                removeView(editorView)
                editorView = null
                showRuntimeOverlay()
                MappingStore.setEnabled(this, true)
                updateBubbleAppearance()
                Toast.makeText(this, "Mapping aktif. Tombol TB untuk on/off.", Toast.LENGTH_SHORT).show()
                sendStateChanged()
            },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48)).apply {
                marginStart = dp(6)
            }
        )

        val mappings = MappingStore.all(this)
        val pointMappings = mappings.filter { !it.isDirection }
        val hasDirections = mappings.any { it.isDirection }

        if (mappings.isEmpty()) {
            val emptyHint = TextView(this).apply {
                text = "Belum ada mapping. Tutup editor, tambahkan tombol di aplikasi, lalu buka editor lagi."
                textSize = 15f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(32), dp(20), dp(32), dp(20))
            }
            root.addView(
                emptyHint,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            )
        }

        if (hasDirections) {
            val config = MappingStore.joystick(this)
            val ring = makeJoystickRing(editor = true)
            val ringLayout = joystickLayout(config, screen)
            ring.setOnTouchListener(
                makeDragListener(screen.x, screen.y, ringLayout.width) { cx, cy ->
                    val latest = MappingStore.joystick(this)
                    MappingStore.saveJoystick(this, latest.copy(x = cx, y = cy))
                }
            )
            root.addView(ring, ringLayout)
        }

        pointMappings.forEach { mapping ->
            val marker = makeMarker(mapping, editor = true)
            val markerSize = dp(MARKER_SIZE_DP)
            val layout = FrameLayout.LayoutParams(markerSize, markerSize, Gravity.TOP or Gravity.START).apply {
                leftMargin = (mapping.x * screen.x - markerSize / 2f).toInt()
                    .coerceIn(0, (screen.x - markerSize).coerceAtLeast(0))
                topMargin = (mapping.y * screen.y - markerSize / 2f).toInt()
                    .coerceIn(0, (screen.y - markerSize).coerceAtLeast(0))
            }
            marker.setOnTouchListener(
                makeDragListener(screen.x, screen.y, markerSize) { cx, cy ->
                    MappingStore.updatePosition(this, mapping.id, cx, cy)
                }
            )
            root.addView(marker, layout)
        }

        // Toolbar terakhir agar selalu berada di atas penanda.
        root.addView(
            toolbar,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                dp(64),
                Gravity.TOP
            )
        )

        val params = overlayParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        )
        try {
            windowManager.addView(root, params)
            editorView = root
        } catch (_: Exception) {
            Toast.makeText(this, "Tidak dapat membuka editor overlay.", Toast.LENGTH_LONG).show()
        }
        sendStateChanged()
    }

    private fun showRuntimeOverlay() {
        removeView(editorView)
        editorView = null
        removeView(markerView)
        markerView = null

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }
        val screen = screenSize()
        val mappings = MappingStore.all(this)
        var visibleCount = 0

        if (mappings.any { it.isDirection }) {
            val ring = makeJoystickRing(editor = false)
            root.addView(ring, joystickLayout(MappingStore.joystick(this), screen))
            visibleCount++
        }

        mappings.filter { !it.isDirection }.forEach { mapping ->
            val marker = makeMarker(mapping, editor = false)
            val size = dp(MARKER_SIZE_DP)
            val layout = FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START).apply {
                leftMargin = (mapping.x * screen.x - size / 2f).toInt()
                topMargin = (mapping.y * screen.y - size / 2f).toInt()
            }
            root.addView(marker, layout)
            visibleCount++
        }

        if (visibleCount > 0) {
            val params = overlayParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            )
            try {
                windowManager.addView(root, params)
                markerView = root
            } catch (_: Exception) {
                Toast.makeText(this, "Gagal menampilkan penanda tombol.", Toast.LENGTH_SHORT).show()
            }
        }
        attachBubble()
        sendStateChanged()
    }

    private fun attachBubble() {
        if (bubbleView != null) return
        val bubble = TextView(this).apply {
            text = "TB"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(37, 99, 235), dp(28))
            elevation = dp(8).toFloat()
            setOnClickListener {
                val enable = !MappingStore.isEnabled(this@MapperAccessibilityService)
                MappingStore.setEnabled(this@MapperAccessibilityService, enable)
                if (!enable) engine.releaseAll()
                updateBubbleAppearance()
                Toast.makeText(
                    this@MapperAccessibilityService,
                    if (enable) "Mapping aktif" else "Mapping dijeda",
                    Toast.LENGTH_SHORT
                ).show()
                sendStateChanged()
            }
            setOnLongClickListener {
                showEditor()
                true
            }
        }
        val params = overlayParams(
            dp(BUBBLE_SIZE_DP),
            dp(BUBBLE_SIZE_DP),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            y = dp(110)
            x = dp(12)
        }
        try {
            windowManager.addView(bubble, params)
            bubbleView = bubble
            updateBubbleAppearance()
        } catch (_: Exception) {
            Toast.makeText(this, "Bubble tidak bisa ditampilkan.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateBubbleAppearance() {
        val bubble = bubbleView ?: return
        val active = MappingStore.isEnabled(this)
        bubble.text = if (active) "ON" else "OFF"
        bubble.background = rounded(
            if (active) Color.rgb(22, 163, 74) else Color.rgb(71, 85, 105),
            dp(28)
        )
    }

    private fun stopOverlay() {
        MappingStore.setEnabled(this, false)
        MappingStore.setCapturing(this, false)
        engine.releaseAll()
        removeView(editorView)
        removeView(markerView)
        removeView(bubbleView)
        editorView = null
        markerView = null
        bubbleView = null
        sendStateChanged()
    }

    private fun makeMarker(mapping: ButtonMapping, editor: Boolean): TextView =
        TextView(this).apply {
            text = mapping.label
            textSize = 11f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(
                if (editor) Color.rgb(37, 99, 235) else Color.rgb(15, 23, 42),
                dp(28)
            )
            alpha = if (editor) 0.95f else 0.28f
            elevation = dp(4).toFloat()
        }

    private fun makeJoystickRing(editor: Boolean): TextView =
        TextView(this).apply {
            text = "JOY"
            textSize = 12f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(if (editor) Color.WHITE else Color.argb(110, 255, 255, 255))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (editor) Color.argb(85, 37, 99, 235) else Color.argb(28, 15, 23, 42))
                setStroke(dp(2), if (editor) Color.rgb(96, 165, 250) else Color.argb(90, 148, 163, 184))
            }
        }

    private fun joystickLayout(config: JoystickConfig, screen: Point): FrameLayout.LayoutParams {
        val size = (config.radius * min(screen.x, screen.y) * 2f).toInt().coerceAtLeast(dp(60))
        return FrameLayout.LayoutParams(size, size, Gravity.TOP or Gravity.START).apply {
            leftMargin = (config.x * screen.x - size / 2f).toInt()
                .coerceIn(0, (screen.x - size).coerceAtLeast(0))
            topMargin = (config.y * screen.y - size / 2f).toInt()
                .coerceIn(0, (screen.y - size).coerceAtLeast(0))
        }
    }

    private fun makeDragListener(
        screenWidth: Int,
        screenHeight: Int,
        viewSize: Int,
        onDone: (Float, Float) -> Unit
    ): View.OnTouchListener {
        var downRawX = 0f
        var downRawY = 0f
        var startLeft = 0
        var startTop = 0
        return View.OnTouchListener { target, event ->
            val params = target.layoutParams as? FrameLayout.LayoutParams ?: return@OnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = event.rawX
                    downRawY = event.rawY
                    startLeft = params.leftMargin
                    startTop = params.topMargin
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.leftMargin = (startLeft + event.rawX - downRawX).toInt()
                        .coerceIn(0, (screenWidth - viewSize).coerceAtLeast(0))
                    params.topMargin = (startTop + event.rawY - downRawY).toInt()
                        .coerceIn(0, (screenHeight - viewSize).coerceAtLeast(0))
                    target.layoutParams = params
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val centerX = params.leftMargin + viewSize / 2f
                    val centerY = params.topMargin + viewSize / 2f
                    onDone(
                        centerX / screenWidth.coerceAtLeast(1),
                        centerY / screenHeight.coerceAtLeast(1)
                    )
                    true
                }
                else -> false
            }
        }
    }

    private fun toolbarButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 10f
            isAllCaps = false
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(8), 0, dp(8), 0)
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(51, 65, 85), dp(10))
            setOnClickListener { action() }
        }

    private fun overlayParams(width: Int, height: Int, flags: Int) =
        WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            flags,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

    private fun screenSize(): Point {
        val point = Point()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealSize(point)
        if (point.x <= 0 || point.y <= 0) {
            point.x = resources.displayMetrics.widthPixels
            point.y = resources.displayMetrics.heightPixels
        }
        return point
    }

    private fun rounded(color: Int, radiusPx: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radiusPx.toFloat()
        }

    private fun removeView(view: View?) {
        if (view == null) return
        try {
            windowManager.removeView(view)
        } catch (_: Exception) {
            // It may already have been removed by the system.
        }
    }

    private fun sendStateChanged() {
        sendBroadcast(Intent(ACTION_STATE_CHANGED).setPackage(packageName))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        engine.releaseAll()
        if (receiverRegistered) {
            try {
                unregisterReceiver(serviceReceiver)
            } catch (_: Exception) {
                // Ignore an already-unregistered receiver.
            }
            receiverRegistered = false
        }
        removeView(editorView)
        removeView(markerView)
        removeView(bubbleView)
        super.onDestroy()
    }

    companion object {
        const val ACTION_SHOW_EDITOR = "com.tapbridge.mapper.SHOW_EDITOR"
        const val ACTION_STOP_OVERLAY = "com.tapbridge.mapper.STOP_OVERLAY"
        const val ACTION_REFRESH_OVERLAY = "com.tapbridge.mapper.REFRESH_OVERLAY"
        const val ACTION_START_OVERLAY = "com.tapbridge.mapper.START_OVERLAY"
        const val ACTION_KEY_CAPTURED = "com.tapbridge.mapper.KEY_CAPTURED"
        const val ACTION_STATE_CHANGED = "com.tapbridge.mapper.STATE_CHANGED"
        const val EXTRA_KEY_CODE = "key_code"

        private const val MARKER_SIZE_DP = 50
        private const val BUBBLE_SIZE_DP = 50
    }
}

private object SettingsCompat {
    fun canDrawOverlays(context: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 23) android.provider.Settings.canDrawOverlays(context) else true
}

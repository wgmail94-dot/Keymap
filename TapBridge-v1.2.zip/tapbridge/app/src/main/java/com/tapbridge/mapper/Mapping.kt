package com.tapbridge.mapper

import android.view.KeyEvent
import java.util.UUID

data class ButtonMapping(
    val id: String = UUID.randomUUID().toString(),
    val keyCode: Int,
    val x: Float = 0.78f,
    val y: Float = 0.70f,
    val mode: String = MODE_TAP
) {
    val label: String
        get() = keyLabel(keyCode)

    /** True jika tombol ini menggerakkan joystick virtual (bukan titik sentuh sendiri). */
    val isDirection: Boolean
        get() = directionOf(mode) >= 0

    companion object {
        const val MODE_TAP = "TAP"
        const val MODE_HOLD = "HOLD"
        const val MODE_RAPID = "RAPID"
        const val MODE_JOY_UP = "JOY_UP"
        const val MODE_JOY_DOWN = "JOY_DOWN"
        const val MODE_JOY_LEFT = "JOY_LEFT"
        const val MODE_JOY_RIGHT = "JOY_RIGHT"

        const val DIR_UP = 0
        const val DIR_DOWN = 1
        const val DIR_LEFT = 2
        const val DIR_RIGHT = 3

        val MODE_ORDER: List<String> = listOf(
            MODE_TAP,
            MODE_HOLD,
            MODE_RAPID,
            MODE_JOY_UP,
            MODE_JOY_DOWN,
            MODE_JOY_LEFT,
            MODE_JOY_RIGHT
        )

        fun nextMode(current: String): String {
            val index = MODE_ORDER.indexOf(current)
            return MODE_ORDER[(index + 1) % MODE_ORDER.size]
        }

        fun modeLabel(mode: String): String = when (mode) {
            MODE_HOLD -> "Tahan"
            MODE_RAPID -> "Ketuk Cepat"
            MODE_JOY_UP -> "Gerak ↑"
            MODE_JOY_DOWN -> "Gerak ↓"
            MODE_JOY_LEFT -> "Gerak ←"
            MODE_JOY_RIGHT -> "Gerak →"
            else -> "Ketuk"
        }

        fun directionOf(mode: String): Int = when (mode) {
            MODE_JOY_UP -> DIR_UP
            MODE_JOY_DOWN -> DIR_DOWN
            MODE_JOY_LEFT -> DIR_LEFT
            MODE_JOY_RIGHT -> DIR_RIGHT
            else -> -1
        }

        fun keyLabel(code: Int): String =
            KeyEvent.keyCodeToString(code)
                .removePrefix("KEYCODE_")
                .replace('_', ' ')
                .take(12)

        private val RESERVED_KEYS: Set<Int> = setOf(
            KeyEvent.KEYCODE_UNKNOWN,
            KeyEvent.KEYCODE_HOME,
            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_POWER,
            KeyEvent.KEYCODE_VOLUME_UP,
            KeyEvent.KEYCODE_VOLUME_DOWN,
            KeyEvent.KEYCODE_VOLUME_MUTE,
            KeyEvent.KEYCODE_MENU
        )

        fun isReservedKey(code: Int): Boolean = code in RESERVED_KEYS
    }
}

/**
 * Joystick virtual. x/y = pusat sebagai pecahan layar (0..1),
 * radius = pecahan dari sisi layar terpendek.
 */
data class JoystickConfig(
    val x: Float = 0.16f,
    val y: Float = 0.68f,
    val radius: Float = 0.12f
) {
    companion object {
        const val MIN_RADIUS = 0.05f
        const val MAX_RADIUS = 0.30f
    }
}

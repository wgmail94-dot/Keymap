package com.tapbridge.mapper

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private var receiverRegistered = false
    private var keyTestView: TextView? = null
    private var showAdvanced = false

    private val colorMuted = Color.rgb(148, 163, 184)
    private val colorCard = Color.rgb(30, 41, 59)
    private val colorOk = Color.rgb(20, 83, 45)
    private val colorNeutral = Color.rgb(51, 65, 85)

    private val appReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                MapperAccessibilityService.ACTION_KEY_CAPTURED -> {
                    val keyCode = intent.getIntExtra(MapperAccessibilityService.EXTRA_KEY_CODE, KeyEvent.KEYCODE_UNKNOWN)
                    handleCapturedKey(keyCode)
                }
                MapperAccessibilityService.ACTION_STATE_CHANGED -> renderScreen()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(11, 18, 32)
        window.navigationBarColor = Color.rgb(11, 18, 32)
        window.decorView.setBackgroundColor(Color.rgb(15, 23, 42))
        renderScreen()
    }

    override fun onStart() {
        super.onStart()
        if (!receiverRegistered) {
            val filter = IntentFilter().apply {
                addAction(MapperAccessibilityService.ACTION_KEY_CAPTURED)
                addAction(MapperAccessibilityService.ACTION_STATE_CHANGED)
            }
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(appReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(appReceiver, filter)
            }
            receiverRegistered = true
        }
        renderScreen()
    }

    override fun onStop() {
        MappingStore.setCapturing(this, false)
        if (receiverRegistered) {
            unregisterReceiver(appReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            if (MappingStore.isCapturing(this)) {
                if (!ButtonMapping.isReservedKey(event.keyCode)) {
                    handleCapturedKey(event.keyCode)
                    return true
                }
            } else {
                keyTestView?.text = "✓ Terbaca: tombol ${ButtonMapping.keyLabel(event.keyCode)}"
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        val isJoystick = (ev.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
        if (isJoystick && ev.actionMasked == MotionEvent.ACTION_MOVE) {
            val stickMoved = abs(ev.getAxisValue(MotionEvent.AXIS_X)) > 0.5f ||
                abs(ev.getAxisValue(MotionEvent.AXIS_Y)) > 0.5f ||
                abs(ev.getAxisValue(MotionEvent.AXIS_Z)) > 0.5f ||
                abs(ev.getAxisValue(MotionEvent.AXIS_RZ)) > 0.5f
            val view = keyTestView
            if (stickMoved && view != null) {
                val message = "Stik analog terbaca, tapi belum bisa dipetakan. Untuk gerak, pakai D-pad atau keyboard WASD."
                if (view.text.toString() != message) view.text = message
            }
        }
        return super.dispatchGenericMotionEvent(ev)
    }

    // ------------------------------------------------------------------ tampilan

    private fun renderScreen() {
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(28))
            setBackgroundColor(Color.rgb(15, 23, 42))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(
                content,
                FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
        setContentView(scroll)
        keyTestView = null

        val accessReady = isAccessibilityServiceEnabled()
        val overlayReady = Settings.canDrawOverlays(this)
        val mappingOn = MappingStore.isEnabled(this)

        content.addView(text("TapBridge", 30, Color.WHITE, true))
        content.addView(
            text("Main game layar sentuh pakai keyboard atau gamepad. Game tidak perlu mendukung gamepad: tombolmu diubah jadi sentuhan layar.", 14, colorMuted),
            lp(top = 4, bottom = 14)
        )

        val statusText = when {
            !accessReady || !overlayReady -> "● Belum siap. Selesaikan Langkah 1."
            mappingOn -> "● Mapping AKTIF. Selamat bermain!"
            else -> "● Izin lengkap. Lanjut ke Langkah 2 dan 3."
        }
        val statusColor = if (accessReady && overlayReady && mappingOn) colorOk else colorCard
        content.addView(card(statusText, statusColor), lp(bottom = 14))

        buildPermissionSection(accessReady, overlayReady)
        buildKeySection()
        buildPlaySection()
        buildFooter()
    }

    private fun buildPermissionSection(accessReady: Boolean, overlayReady: Boolean) {
        content.addView(stepTitle("Langkah 1 — Beri izin"), lp(top = 4, bottom = 6))

        if (accessReady) {
            content.addView(card("✓ Accessibility sudah aktif", colorOk), lp(bottom = 8))
        } else {
            content.addView(actionButton("Aktifkan Accessibility") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }, lp(bottom = 4))
            content.addView(
                text("Di daftar, pilih TapBridge lalu nyalakan. Kalau tombolnya abu-abu (Android 13+), ketuk 'Buka info aplikasi' di bawah, tekan menu ⋮ di pojok kanan atas, pilih 'Izinkan setelan terbatas', lalu coba lagi.", 12, colorMuted),
                lp(bottom = 4)
            )
            content.addView(secondaryButton("Buka info aplikasi") {
                startActivity(
                    Intent(
                        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName")
                    )
                )
            }, lp(bottom = 10))
        }

        if (overlayReady) {
            content.addView(card("✓ Izin tampil di atas aplikasi sudah aktif", colorOk), lp(bottom = 8))
        } else {
            content.addView(actionButton("Izinkan tampil di atas aplikasi") {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }, lp(bottom = 8))
        }
    }

    private fun buildKeySection() {
        content.addView(stepTitle("Langkah 2 — Pilih tombol"), lp(top = 14, bottom = 6))
        content.addView(text("Pilih cepat untuk gerak karakter:", 13, colorMuted), lp(bottom = 6))

        val presetRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        presetRow.addView(actionButton("Keyboard WASD") {
            addPreset(
                listOf(
                    Pair(KeyEvent.KEYCODE_W, ButtonMapping.MODE_JOY_UP),
                    Pair(KeyEvent.KEYCODE_S, ButtonMapping.MODE_JOY_DOWN),
                    Pair(KeyEvent.KEYCODE_A, ButtonMapping.MODE_JOY_LEFT),
                    Pair(KeyEvent.KEYCODE_D, ButtonMapping.MODE_JOY_RIGHT)
                )
            )
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        presetRow.addView(
            actionButton("D-pad / Panah") {
                addPreset(
                    listOf(
                        Pair(KeyEvent.KEYCODE_DPAD_UP, ButtonMapping.MODE_JOY_UP),
                        Pair(KeyEvent.KEYCODE_DPAD_DOWN, ButtonMapping.MODE_JOY_DOWN),
                        Pair(KeyEvent.KEYCODE_DPAD_LEFT, ButtonMapping.MODE_JOY_LEFT),
                        Pair(KeyEvent.KEYCODE_DPAD_RIGHT, ButtonMapping.MODE_JOY_RIGHT)
                    )
                )
            },
            LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) }
        )
        content.addView(presetRow, lp(bottom = 10))

        content.addView(text("Untuk tombol aksi (serang, lompat, dll):", 13, colorMuted), lp(bottom = 6))
        val addRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val capturing = MappingStore.isCapturing(this)
        addRow.addView(
            actionButton(if (capturing) "Tekan satu tombol sekarang…" else "+ Tambah tombol") {
                MappingStore.setCapturing(this, true)
                toast("Tekan satu tombol keyboard atau gamepad sekarang.")
                renderScreen()
            },
            LinearLayout.LayoutParams(0, dp(48), 1f)
        )
        if (capturing) {
            addRow.addView(
                secondaryButton("Batal") {
                    MappingStore.setCapturing(this, false)
                    renderScreen()
                },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48)).apply {
                    marginStart = dp(8)
                }
            )
        }
        content.addView(addRow, lp(bottom = 10))

        val testCard = TextView(this).apply {
            text = "Tes tombol: tekan tombol keyboard/gamepad di layar ini untuk melihat apakah terbaca."
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(colorCard, 14)
        }
        keyTestView = testCard
        content.addView(testCard, lp(bottom = 12))

        val mappings = MappingStore.all(this)
        if (mappings.isEmpty()) {
            content.addView(card("Belum ada tombol. Pilih WASD / D-pad di atas, atau ketuk '+ Tambah tombol'.", colorCard), lp(bottom = 8))
            return
        }

        mappings.forEach { mapping ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(9), dp(8), dp(9))
                background = rounded(colorCard, 14)
            }
            val details = TextView(this).apply {
                text = "Tombol ${mapping.label}\n${modeHelp(mapping.mode)}"
                setTextColor(Color.WHITE)
                textSize = 13f
                setLineSpacing(dp(2).toFloat(), 1f)
            }
            row.addView(details, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(smallButton(ButtonMapping.modeLabel(mapping.mode)) {
                MappingStore.updateMode(this, mapping.id, ButtonMapping.nextMode(mapping.mode))
                renderScreen()
            })
            row.addView(
                smallButton("Hapus") {
                    MappingStore.remove(this, mapping.id)
                    renderScreen()
                },
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, dp(48)).apply {
                    marginStart = dp(6)
                }
            )
            content.addView(row, lp(bottom = 8))
        }
        content.addView(
            text("Ketuk kotak mode (Ketuk / Tahan / Ketuk Cepat / Gerak) untuk menggantinya.", 12, colorMuted),
            lp(bottom = 4)
        )
    }

    private fun buildPlaySection() {
        content.addView(stepTitle("Langkah 3 — Atur posisi lalu main"), lp(top = 14, bottom = 6))
        content.addView(actionButton("▶ Tampilkan tombol TB") {
            if (!isAccessibilityServiceEnabled()) {
                toast("Selesaikan Langkah 1 dulu: aktifkan Accessibility.")
            } else if (!Settings.canDrawOverlays(this)) {
                toast("Selesaikan Langkah 1 dulu: izinkan tampil di atas aplikasi.")
            } else {
                sendServiceAction(MapperAccessibilityService.ACTION_START_OVERLAY)
                toast("Tombol TB muncul. Sekarang buka game-mu.")
            }
        }, lp(bottom = 8))
        content.addView(
            card(
                "1. Buka game-mu (pakai orientasi layar yang akan dipakai main).\n" +
                    "2. Tekan LAMA tombol bulat TB di pojok kanan layar.\n" +
                    "3. Geser lingkaran ke tombol yang sama di game. Lingkaran JOY ke pusat joystick game. Tekan SELESAI.\n" +
                    "4. Main! TB hijau = ON. Ketuk TB untuk ON/OFF.",
                colorCard
            ),
            lp(bottom = 8)
        )
    }

    private fun buildFooter() {
        content.addView(
            card(
                "Perlu tahu:\n" +
                    "• Stik analog gamepad belum bisa dipakai. Tombol dan D-pad bisa; untuk gerak pakai D-pad atau keyboard WASD.\n" +
                    "• Menyentuh layar dengan jari dapat memutus sentuhan dari TapBridge.\n" +
                    "• Beberapa game menolak input sintetis. Tidak ada bypass anti-cheat.",
                colorCard
            ),
            lp(top = 10, bottom = 10)
        )
        content.addView(secondaryButton("Matikan overlay dan mapping") {
            sendServiceAction(MapperAccessibilityService.ACTION_STOP_OVERLAY)
            MappingStore.setEnabled(this, false)
            renderScreen()
        }, lp(bottom = 8))

        content.addView(
            secondaryButton(if (showAdvanced) "Sembunyikan pengaturan lanjutan" else "Pengaturan lanjutan") {
                showAdvanced = !showAdvanced
                renderScreen()
            },
            lp(bottom = 8)
        )

        if (showAdvanced) {
            val joystick = MappingStore.joystick(this)
            content.addView(
                card(
                    "Ukuran joystick virtual: ${(joystick.radius * 100).toInt()}%\n" +
                        "Makin besar, makin jauh jari virtual bergeser. Sesuaikan dengan ukuran joystick di game. Posisinya digeser lewat tombol TB (tekan lama).",
                    colorCard
                ),
                lp(bottom = 8)
            )
            val radiusRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            radiusRow.addView(actionButton("Lebih kecil −") {
                adjustJoystickRadius(-0.02f)
            }, LinearLayout.LayoutParams(0, dp(48), 1f))
            radiusRow.addView(
                actionButton("Lebih besar +") {
                    adjustJoystickRadius(0.02f)
                },
                LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginStart = dp(8) }
            )
            content.addView(radiusRow, lp(bottom = 8))
            content.addView(
                card(
                    "Arti mode:\n" +
                        "• Ketuk: satu sentuhan singkat.\n" +
                        "• Tahan: sentuhan tertahan selama tombol ditekan.\n" +
                        "• Ketuk Cepat: ketukan berulang selama tombol ditahan.\n" +
                        "• Gerak: tombol menggerakkan joystick virtual (bisa diagonal).",
                    colorCard
                ),
                lp(bottom = 8)
            )
        }

        content.addView(text("TapBridge 1.2.0 • Android 8.0+", 12, Color.rgb(100, 116, 139)), lp(top = 8))
    }

    // ------------------------------------------------------------------ aksi

    private fun handleCapturedKey(keyCode: Int) {
        MappingStore.setCapturing(this, false)
        if (ButtonMapping.isReservedKey(keyCode)) {
            toast("Tombol sistem tidak dapat dipetakan.")
            renderScreen()
            return
        }
        val existing = MappingStore.find(this, keyCode)
        if (existing != null) {
            toast("${ButtonMapping.keyLabel(keyCode)} sudah ada di daftar.")
        } else {
            val spot = nextSpot()
            MappingStore.upsert(this, ButtonMapping(keyCode = keyCode, x = spot.first, y = spot.second))
            toast("Tombol ${ButtonMapping.keyLabel(keyCode)} ditambahkan.")
        }
        renderScreen()
    }

    /** Posisi awal berbeda-beda supaya lingkaran tidak menumpuk di editor. */
    private fun nextSpot(): Pair<Float, Float> {
        val index = MappingStore.all(this).count { !it.isDirection }
        return Pair(0.60f + 0.08f * (index % 5), 0.45f + 0.12f * ((index / 5) % 4))
    }

    private fun addPreset(pairs: List<Pair<Int, String>>) {
        pairs.forEach { (keyCode, mode) ->
            MappingStore.upsert(this, ButtonMapping(keyCode = keyCode, mode = mode))
        }
        toast("Tombol gerak ditambahkan. Lanjut ke Langkah 3.")
        renderScreen()
    }

    private fun adjustJoystickRadius(delta: Float) {
        val current = MappingStore.joystick(this)
        val updated = current.copy(
            radius = (current.radius + delta).coerceIn(JoystickConfig.MIN_RADIUS, JoystickConfig.MAX_RADIUS)
        )
        MappingStore.saveJoystick(this, updated)
        sendServiceAction(MapperAccessibilityService.ACTION_REFRESH_OVERLAY)
        renderScreen()
    }

    private fun sendServiceAction(action: String) {
        sendBroadcast(Intent(action).setPackage(packageName))
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val component = ComponentName(this, MapperAccessibilityService::class.java)
        val expected = setOf(component.flattenToString(), component.flattenToShortString())
        return enabled.split(':').any { entry -> expected.any { it.equals(entry, ignoreCase = true) } }
    }

    private fun modeHelp(mode: String): String = when (mode) {
        ButtonMapping.MODE_HOLD -> "Ditahan selama tombol ditekan"
        ButtonMapping.MODE_RAPID -> "Mengetuk berulang saat ditahan"
        ButtonMapping.MODE_JOY_UP -> "Gerak karakter: atas"
        ButtonMapping.MODE_JOY_DOWN -> "Gerak karakter: bawah"
        ButtonMapping.MODE_JOY_LEFT -> "Gerak karakter: kiri"
        ButtonMapping.MODE_JOY_RIGHT -> "Gerak karakter: kanan"
        else -> "Mengetuk 1x di titik layar"
    }

    // ------------------------------------------------------------------ pembantu UI

    private fun stepTitle(value: String): TextView = text(value, 18, Color.WHITE, true)

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun card(value: String, color: Int): TextView =
        TextView(this).apply {
            text = value
            textSize = 13f
            setTextColor(Color.WHITE)
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(color, 14)
            setLineSpacing(dp(3).toFloat(), 1f)
        }

    private fun actionButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(37, 99, 235), 12)
            setOnClickListener { action() }
        }

    private fun secondaryButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 13f
            setTextColor(Color.WHITE)
            background = rounded(colorNeutral, 12)
            setOnClickListener { action() }
        }

    private fun smallButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 11f
            minWidth = 0
            minimumWidth = 0
            setPadding(dp(8), 0, dp(8), 0)
            setTextColor(Color.WHITE)
            background = rounded(colorNeutral, 10)
            setOnClickListener { action() }
        }

    private fun rounded(color: Int, radiusDp: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
        }

    private fun lp(
        start: Int = 0,
        top: Int = 0,
        bottom: Int = 0
    ) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply {
        marginStart = dp(start)
        topMargin = dp(top)
        bottomMargin = dp(bottom)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}

package com.tapbridge.mapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Point
import android.os.Handler
import java.util.ArrayDeque
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Mesin sentuhan. Semua sentuhan aktif (tap, tahan, rapid, joystick) digabung dalam SATU gesture
 * multi-stroke, sehingga bisa berjalan bersamaan (mis. joystick + tombol serang).
 *
 * - Tap     : stroke singkat sekali jalan.
 * - Tahan   : stroke yang disambung (continueStroke) selama tombol ditekan.
 * - Rapid   : tap berulang selama tombol ditekan.
 * - Joystick: satu sentuhan tertahan yang bergeser dari pusat ke arah tombol yang ditekan.
 *
 * Semua fungsi publik dipanggil dari main thread.
 */
internal class TouchEngine(
    private val service: AccessibilityService,
    private val handler: Handler,
    private val screenSize: () -> Point,
    private val joystickConfig: () -> JoystickConfig
) {
    private class TapPoint(val x: Float, val y: Float)

    private class Contact(
        var x: Float,
        var y: Float,
        val startX: Float = x,
        val startY: Float = y
    ) {
        var lastX: Float = startX
        var lastY: Float = startY
        var stroke: GestureDescription.StrokeDescription? = null
        var releasing: Boolean = false
    }

    private val holds = LinkedHashMap<Int, Contact>()
    private var joy: Contact? = null
    private val dirKeys = HashMap<Int, Int>()
    private val pendingTaps = ArrayDeque<TapPoint>()
    private val rapidJobs = HashMap<Int, Runnable>()
    private var inFlight = false
    private var pumpQueued = false

    private val pumpRunnable = Runnable {
        pumpQueued = false
        pump()
    }

    private val callback = object : AccessibilityService.GestureResultCallback() {
        override fun onCompleted(gestureDescription: GestureDescription?) {
            inFlight = false
            if (holds.isNotEmpty() || joy != null) {
                pump()
            } else if (pendingTaps.isNotEmpty()) {
                queuePump(TAP_GAP_MS)
            }
        }

        override fun onCancelled(gestureDescription: GestureDescription?) {
            inFlight = false
            resetStrokes()
            queuePump(RETRY_MS)
        }
    }

    // ---------------------------------------------------------------- API publik

    fun tap(x: Float, y: Float) {
        if (pendingTaps.size >= MAX_PENDING_TAPS) return
        pendingTaps.addLast(TapPoint(x, y))
        requestPump()
    }

    fun holdDown(keyCode: Int, x: Float, y: Float) {
        val existing = holds[keyCode]
        if (existing != null) {
            existing.releasing = false
            return
        }
        if (holds.size >= MAX_HOLDS) return
        holds[keyCode] = Contact(x, y)
        requestPump()
    }

    fun rapidStart(keyCode: Int, x: Float, y: Float) {
        if (rapidJobs.containsKey(keyCode)) return
        tap(x, y)
        val job = object : Runnable {
            override fun run() {
                tap(x, y)
                handler.postDelayed(this, RAPID_INTERVAL_MS)
            }
        }
        rapidJobs[keyCode] = job
        handler.postDelayed(job, RAPID_INTERVAL_MS)
    }

    fun directionDown(keyCode: Int, direction: Int) {
        dirKeys[keyCode] = direction
        updateJoystick()
    }

    /** Dipanggil pada setiap ACTION_UP: melepas apa pun yang ditahan oleh tombol ini. */
    fun keyUp(keyCode: Int) {
        val job = rapidJobs.remove(keyCode)
        if (job != null) handler.removeCallbacks(job)

        val hold = holds[keyCode]
        if (hold != null) {
            hold.releasing = true
            requestPump()
        }
        if (dirKeys.remove(keyCode) != null) updateJoystick()
    }

    fun releaseAll() {
        for (job in rapidJobs.values) handler.removeCallbacks(job)
        rapidJobs.clear()
        pendingTaps.clear()
        dirKeys.clear()
        for (contact in holds.values) contact.releasing = true
        joy?.releasing = true
        requestPump()
    }

    // ---------------------------------------------------------------- joystick

    private fun updateJoystick() {
        var vx = 0f
        var vy = 0f
        for (dir in dirKeys.values) {
            when (dir) {
                ButtonMapping.DIR_UP -> vy -= 1f
                ButtonMapping.DIR_DOWN -> vy += 1f
                ButtonMapping.DIR_LEFT -> vx -= 1f
                ButtonMapping.DIR_RIGHT -> vx += 1f
            }
        }

        val current = joy
        if (vx == 0f && vy == 0f) {
            if (current != null) {
                current.releasing = true
                requestPump()
            }
            return
        }

        val length = sqrt(vx * vx + vy * vy)
        vx /= length
        vy /= length

        val screen = screenSize()
        val w = screen.x.coerceAtLeast(2)
        val h = screen.y.coerceAtLeast(2)
        val cfg = joystickConfig()
        val radiusPx = cfg.radius * min(w, h)
        val tx = (cfg.x + vx * radiusPx / w).coerceIn(0f, 1f)
        val ty = (cfg.y + vy * radiusPx / h).coerceIn(0f, 1f)

        if (current == null) {
            joy = Contact(tx, ty, cfg.x, cfg.y)
        } else {
            current.releasing = false
            current.x = tx
            current.y = ty
        }
        requestPump()
    }

    // ---------------------------------------------------------------- pengiriman gesture

    private fun requestPump() {
        if (!inFlight) pump()
    }

    private fun queuePump(delayMs: Long) {
        if (pumpQueued) return
        pumpQueued = true
        handler.postDelayed(pumpRunnable, delayMs)
    }

    private fun pump() {
        if (inFlight) return
        val screen = screenSize()
        val w = screen.x
        val h = screen.y
        if (w < 2 || h < 2) return

        val builder = GestureDescription.Builder()
        val maxStrokes = GestureDescription.getMaxStrokeCount()
        var count = 0

        try {
            val iterator = holds.entries.iterator()
            while (iterator.hasNext() && count < maxStrokes) {
                val contact = iterator.next().value
                if (contact.stroke == null && contact.releasing) {
                    // Tombol dilepas sebelum sentuhan sempat dikirim: jadikan tap supaya tidak hilang.
                    pendingTaps.addFirst(TapPoint(contact.x, contact.y))
                    iterator.remove()
                    continue
                }
                builder.addStroke(buildStroke(contact, w, h))
                count++
                if (contact.releasing) iterator.remove()
            }

            val j = joy
            if (j != null && count < maxStrokes) {
                if (j.stroke == null && j.releasing) {
                    joy = null
                } else {
                    builder.addStroke(buildStroke(j, w, h))
                    count++
                    if (j.releasing) joy = null
                }
            }

            while (count < maxStrokes && pendingTaps.isNotEmpty()) {
                val tapPoint = pendingTaps.removeFirst()
                val path = Path()
                path.moveTo(tapPoint.x * (w - 1), tapPoint.y * (h - 1))
                builder.addStroke(GestureDescription.StrokeDescription(path, 0L, TAP_MS))
                count++
            }
        } catch (_: Exception) {
            resetStrokes()
            queuePump(RETRY_MS)
            return
        }

        if (count == 0) return

        inFlight = true
        val accepted = try {
            service.dispatchGesture(builder.build(), callback, handler)
        } catch (_: Exception) {
            false
        }
        if (!accepted) {
            inFlight = false
            resetStrokes()
            queuePump(RETRY_MS)
        }
    }

    private fun buildStroke(contact: Contact, w: Int, h: Int): GestureDescription.StrokeDescription {
        val targetX = contact.x * (w - 1)
        val targetY = contact.y * (h - 1)
        val previous = contact.stroke
        val path = Path()

        if (previous == null) {
            path.moveTo(contact.startX * (w - 1), contact.startY * (h - 1))
            if (contact.startX != contact.x || contact.startY != contact.y) {
                path.lineTo(targetX, targetY)
            }
            val stroke = GestureDescription.StrokeDescription(path, 0L, SEGMENT_MS, true)
            contact.stroke = stroke
            contact.lastX = contact.x
            contact.lastY = contact.y
            return stroke
        }

        path.moveTo(contact.lastX * (w - 1), contact.lastY * (h - 1))
        if (contact.lastX != contact.x || contact.lastY != contact.y) {
            path.lineTo(targetX, targetY)
        }
        val keepDown = !contact.releasing
        val stroke = previous.continueStroke(
            path,
            0L,
            if (keepDown) SEGMENT_MS else RELEASE_MS,
            keepDown
        )
        contact.stroke = stroke
        contact.lastX = contact.x
        contact.lastY = contact.y
        return stroke
    }

    /** Gesture dibatalkan/ditolak: sentuhan tertahan harus dimulai ulang dari awal. */
    private fun resetStrokes() {
        val iterator = holds.entries.iterator()
        while (iterator.hasNext()) {
            val contact = iterator.next().value
            if (contact.releasing) iterator.remove() else contact.stroke = null
        }
        val j = joy
        if (j != null) {
            if (j.releasing) joy = null else j.stroke = null
        }
    }

    companion object {
        private const val TAP_MS = 40L
        private const val SEGMENT_MS = 60L
        private const val RELEASE_MS = 10L
        private const val TAP_GAP_MS = 15L
        private const val RETRY_MS = 40L
        private const val RAPID_INTERVAL_MS = 90L
        private const val MAX_PENDING_TAPS = 8
        private const val MAX_HOLDS = 8
    }
}

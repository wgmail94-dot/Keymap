package com.tapbridge.mapper

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object MappingStore {
    private const val PREFS = "tapbridge_preferences"
    private const val KEY_MAPPINGS = "mappings"
    private const val KEY_ENABLED = "mapping_enabled"
    private const val KEY_CAPTURING = "capture_key"
    private const val KEY_JOY_X = "joystick_x"
    private const val KEY_JOY_Y = "joystick_y"
    private const val KEY_JOY_RADIUS = "joystick_radius"

    // Cache di memori: onKeyEvent dipanggil sangat sering, jadi JSON tidak di-parse ulang tiap tombol.
    @Volatile
    private var cachedList: List<ButtonMapping>? = null

    @Volatile
    private var cachedByKey: Map<Int, ButtonMapping> = emptyMap()

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun publish(list: List<ButtonMapping>) {
        cachedList = list
        cachedByKey = list.associateBy { it.keyCode }
    }

    private fun parse(raw: String): List<ButtonMapping> {
        return try {
            val array = JSONArray(raw)
            val result = ArrayList<ButtonMapping>()
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val keyCode = item.optInt("keyCode", -1)
                if (keyCode < 0) continue
                val mode = item.optString("mode", ButtonMapping.MODE_TAP)
                result.add(
                    ButtonMapping(
                        id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                        keyCode = keyCode,
                        x = item.optDouble("x", 0.78).toFloat().coerceIn(0.02f, 0.98f),
                        y = item.optDouble("y", 0.70).toFloat().coerceIn(0.04f, 0.96f),
                        mode = if (mode in ButtonMapping.MODE_ORDER) mode else ButtonMapping.MODE_TAP
                    )
                )
            }
            result
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun all(context: Context): List<ButtonMapping> {
        cachedList?.let { return it }
        val parsed = parse(prefs(context).getString(KEY_MAPPINGS, "[]") ?: "[]")
        publish(parsed)
        return parsed
    }

    /** Pencarian cepat berdasarkan keyCode (dipakai di jalur input). */
    fun find(context: Context, keyCode: Int): ButtonMapping? {
        if (cachedList == null) all(context)
        return cachedByKey[keyCode]
    }

    @Synchronized
    fun save(context: Context, mappings: List<ButtonMapping>) {
        val array = JSONArray()
        mappings.forEach { mapping ->
            array.put(
                JSONObject()
                    .put("id", mapping.id)
                    .put("keyCode", mapping.keyCode)
                    .put("x", mapping.x.toDouble())
                    .put("y", mapping.y.toDouble())
                    .put("mode", mapping.mode)
            )
        }
        prefs(context).edit().putString(KEY_MAPPINGS, array.toString()).apply()
        publish(mappings.toList())
    }

    @Synchronized
    fun upsert(context: Context, mapping: ButtonMapping) {
        val current = all(context).filterNot { it.keyCode == mapping.keyCode || it.id == mapping.id }
        save(context, current + mapping)
    }

    @Synchronized
    fun remove(context: Context, id: String) {
        save(context, all(context).filterNot { it.id == id })
    }

    @Synchronized
    fun updatePosition(context: Context, id: String, x: Float, y: Float) {
        val updated = all(context).map {
            if (it.id == id) it.copy(
                x = x.coerceIn(0.02f, 0.98f),
                y = y.coerceIn(0.04f, 0.96f)
            ) else it
        }
        save(context, updated)
    }

    @Synchronized
    fun updateMode(context: Context, id: String, mode: String) {
        val updated = all(context).map {
            if (it.id == id) it.copy(mode = mode) else it
        }
        save(context, updated)
    }

    fun joystick(context: Context): JoystickConfig {
        val p = prefs(context)
        val d = JoystickConfig()
        return JoystickConfig(
            x = p.getFloat(KEY_JOY_X, d.x).coerceIn(0.03f, 0.97f),
            y = p.getFloat(KEY_JOY_Y, d.y).coerceIn(0.05f, 0.95f),
            radius = p.getFloat(KEY_JOY_RADIUS, d.radius)
                .coerceIn(JoystickConfig.MIN_RADIUS, JoystickConfig.MAX_RADIUS)
        )
    }

    fun saveJoystick(context: Context, config: JoystickConfig) {
        prefs(context).edit()
            .putFloat(KEY_JOY_X, config.x)
            .putFloat(KEY_JOY_Y, config.y)
            .putFloat(KEY_JOY_RADIUS, config.radius)
            .apply()
    }

    fun isEnabled(context: Context): Boolean =
        prefs(context).getBoolean(KEY_ENABLED, false)

    fun setEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_ENABLED, enabled).apply()
    }

    fun isCapturing(context: Context): Boolean =
        prefs(context).getBoolean(KEY_CAPTURING, false)

    fun setCapturing(context: Context, capturing: Boolean) {
        prefs(context).edit().putBoolean(KEY_CAPTURING, capturing).apply()
    }
}
